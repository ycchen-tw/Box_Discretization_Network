DIR=../TrainDataset/img
ODIR=/path/to/OUTPUT_DIR/
CUDA_VISIBLE_DEVICES=0 python demo/test_single_image.py \
	--min-image-size 1000 \
	--config-file ../BDN_weights/BDN.yam \
	--output_dir  $ODIR\
	--img $DIR
	
